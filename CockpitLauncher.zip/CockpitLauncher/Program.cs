﻿using Microsoft.Win32.TaskScheduler;
using System;
using System.Collections.Generic;
using System.Deployment.Application;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


namespace CockpitLauncher
{
    class Program
    {
        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;
        const int SW_SHOW = 5;

        static void Main(string[] args)
        {
            ShowWindow(GetConsoleWindow(), SW_HIDE);
            AddShortcutToStartupGroup("AlphaDigitAll", "CockpitLauncher");
            Thread.Sleep(5000);
            //Toast.ShowImageToast("CockpitLauncher", "Cockpit Launcher", "Hello there", "AlphaDigitAll.png");
            var name = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            if (name.Contains('\\')) name = name.Split('\\')[1];
            Toast.ShowToast("CockpitLauncher", "Cockpit Launcher", "Hello there, " + name + "!");
        }

        public static void AddShortcutToStartupGroup(string publisherName, string productName)
        {
            if (ApplicationDeployment.IsNetworkDeployed && ApplicationDeployment.CurrentDeployment.IsFirstRun)
            {
                string startupPath = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
                startupPath = Path.Combine(startupPath, productName) + ".appref-ms";
                if (!File.Exists(startupPath))
                {
                    string allProgramsPath = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
                    string shortcutPath = Path.Combine(allProgramsPath, publisherName);
                    shortcutPath = Path.Combine(shortcutPath, productName) + ".appref-ms";
                    File.Copy(shortcutPath, startupPath);
                }
            }
            try
            {
                using (TaskService ts = new TaskService())
                {
                    TaskDefinition td = ts.NewTask();
                    td.RegistrationInfo.Description = "Adds task to check data on logon";

                    td.Triggers.Add(new SessionStateChangeTrigger(TaskSessionStateChangeType.SessionUnlock));

                    string allProgramsPath = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
                    string shortcutPath = Path.Combine(allProgramsPath, publisherName);
                    shortcutPath = Path.Combine(shortcutPath, productName) + ".appref-ms";
                    td.Actions.Add(new ExecAction(shortcutPath));

                    ts.RootFolder.RegisterTaskDefinition(@"CockpitLauncher", td);
                    //Toast.ShowToast("CockpitLauncher", "Cockpit Launcher", "Registered on startup");
                }
            }
            catch (Exception) { }
        }
    }
}
