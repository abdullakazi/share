﻿var Layout = {

    getNavbarData: _ => {
        //$.get('https://localhost:44321/api/nav', function (data, status) {
        //    return status == 'success' ? data : null;
        //});
        $.ajax({
            url: 'https://localhost:44321/api/nav?psno=20036412&dept=3858',
            type: 'GET',
            async: false,
            success: function (data) {
                result = data != null || data != undefined ? data : null;
            }
        });
        return result;
    },

    setNavbar: navbarData => {
        var TMain = $('#ulTemplate').html();
        var TSub = $('#divTemplate .ulBottomLevel').html();
        var manipulateFunc = d => {
            if (d.children.length) {
                d["menuClass"] = "menu-toggle waves-effect waves-block";
                d["URL"] = 'javascript:void(0);';
            }
            else d["menuClass"] = "waves-effect waves-block";
            d["Icon"] = 'sentiment_very_satisfied';
            d["Title"] += d["Count"] && parseInt(d["Count"]) > 0 ? "(" + d["Count"] + ")" : "";
            return d;
        }
        function GetDataRecursive(data, el, step = '', stepAdd = '', template = TSub) {
            $(el).alphaBindData({
                data: data.filter(q => q.checked),
                template: step + template,
                replace: false,
                mapper: manipulateFunc
            });
            $(el).find('.unp').each(function () {
                var s = step + stepAdd, i = parseInt($(this).attr('id').split('_')[1]);
                var d = data.filter(q => q.ID == i)[0].children;
                $(this).removeClass('unp')
                if (d.length > 0) {
                    $(this).append('<ul class="ml-menu" id="ulChild_' + i + '"></ul>')
                    GetDataRecursive(d, $(this).find('ul'), s);
                }
            });
        }
        if (navbarData != null) GetDataRecursive(navbarData, $('#ulMainMenu'), '', '', TMain)
        else console.log('No data found');
    },

    bindNavChildrens: (navChildrens, id) => {

        var liBottomLevel = $('#divTemplate .ulBottomLevel').html();
        $('#liTopLevel_' + id).append('<ul class="ml-menu" id="ulChild_' + id + '"> </ul>');
        navChildrens.forEach(navChild => {

            if (navChild["children"].length > 0) {
                $('#ulChild_' + navChild["ParentID"]).append(liBottomLevel.replace('${URL}', 'javascript:void(0);')
                    .replace('${Title}', navChild["Title"])
                    .replace('${ExtraUL}', '<ul class="ml-menu" id="ulChild_' + navChild["ID"] + '"> </ul>')
                    .replace('${menuClass}', 'menu-toggle waves-effect waves-block')

                    .replace('${Count}',''));
                Layout.bindNavChildrens(navChild["children"], navChild["ID"]);
            } else {
                $('#ulChild_' + navChild["ParentID"]).append(liBottomLevel.replace('${URL}', 'controller/action')
                    .replace('${Title}', navChild["Title"]));
            }

        });


    }


}